#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include<time.h>

#define width 60
#define gravity -0.15
#define radius 12
#define BG_Width 1066
#define height_pipe 600
#define gap 90
#define speed 2

int flag=0;
int flag2=0;


void buildblocks(double x[]);
void leftshift(double x[], double y[], int score);
int controlScreen(int opt, int score, int col);
void startScreen();
void showHighscore();
void showCredits();
void gameOver(int score);
void moveBall(double ball[]);
int checkCollision(int x,double y,double blockX,double height, int score);
void replayGame(double ballY[], double blocks[], double background[]  );
int currentScore(int score, int  ballX, double block );


void buildblocks(double x[]){

    int i;
    //iSetColor(255,0,0);

    for(i = 0; i < 11; i+=3){
        //iFilledRectangle(x[i], 0, x[i+1] , x[i+2]);
        //iFilledRectangle(x[i], gap+x[i+2], x[i+1], 600-gap-x[i+2]);

        drawTexture(x[i] , x[i+2]-height_pipe , pipe_Down);
        drawTexture(x[i] , x[i+2]+gap , pipe_Up);

    }

    if(x[0]<=-60){

        for(i = 0; i < 9; i++){
            x[i] = x[i+3];
        }
        x[9] = x[6]+400;
        x[11] = rand()%500;
        flag2=0;
        printf("%d\n",x[11]);
    }



}

void leftshift(double x[], double y[], int score){

        int i;



        for(i = 0; i < 12; i+=3){

            x[i]=x[i]-speed;

            /*if(x[i] > 0){

                x[i]=x[i]-speed;
            }

            else{

                x[i+1] = x[i+1]-speed;

            }*/

        }


            y[0]-=speed;
            y[1]-=speed;


        if(y[1]<=0){
            y[0]=0;
            y[1]=BG_Width;
        }


}

int controlScreen(int opt, int score, int col){
    if(opt==0 && col==1){
        iClear();
        startScreen();
        opt=0;
	}
    else if(opt==2 && col==1){
        iClear();
        showHighscore();
        opt=2;
	}
	else if(opt==3 && col==1){
        iClear();
        showCredits();
        opt=3;
    }
	else if(opt==4 && col==1){
	    iClear();
        exit(0);
	}
	else  if(opt==5 && col==1){
        iClear();
        gameOver(score);
        opt=5;

	}

	return opt;
}


void startScreen(){
    //iShowBMP(0,0,"background for flappy.bmp");
    drawTexture(0,0,bGround);
    //printf("check\n");
    iSetColor(67,3,168);
    iText(230,500,"Flappy Bird",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(130,300,"1.Play",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(380,300,"2.Highscores",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(130,100,"3.Credits",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(380,100,"4.Exit",GLUT_BITMAP_TIMES_ROMAN_24);


}

void showHighscore(){

    int hScore[5]={},i=0,x=100,y=500;

    char txt[10];


    drawTexture(0,0,bGround);
    FILE * fp;

    fp = fopen("flappy_highScore", "rb");
     if (fp == NULL) {
        printf("File doesn't exists!\n");
        fp = fopen("flappy_highScore", "wb");
    }

    while(fread(&hScore[i], sizeof(int), 1, fp) == 1) {
        i++;
    }
    fclose(fp);

    iSetColor(67,3,168);
    iText(100,550,"Highscores:",GLUT_BITMAP_HELVETICA_18);

    for(i=0;i<5;i++){

        itoa(i+1,txt,10);
        txt[1]='.';
        txt[2]=0;
        iText(x,y,txt,GLUT_BITMAP_HELVETICA_18);
        x+=25;

        itoa(hScore[i],txt,10);
        iText(x,y,txt,GLUT_BITMAP_HELVETICA_18);
        x=100;
        y-=50;
    }

    iText(130,100,"1.Play",GLUT_BITMAP_HELVETICA_18);
    iText(250,100,"3.Credits",GLUT_BITMAP_HELVETICA_18);
    iText(380,100,"4.Exit",GLUT_BITMAP_HELVETICA_18);
}

void showCredits(){
    drawTexture(0,0,bGround);
    iSetColor(67,3,168);
    iText(50,500,"1. Abdullah Al Ishtiaq",GLUT_BITMAP_HELVETICA_18);
    iText(50,480,"    1505080",GLUT_BITMAP_HELVETICA_18);
    iText(50,450,"2. Shashata Sawmya",GLUT_BITMAP_HELVETICA_18);
    iText(50,430,"    1505089",GLUT_BITMAP_HELVETICA_18);

    iText(280,500,"Advisor:     ",GLUT_BITMAP_HELVETICA_18);
    iText(280,480,"Siddharta Shankor Roy     ",GLUT_BITMAP_HELVETICA_18);
    iText(280,460,"Lecturer     ",GLUT_BITMAP_HELVETICA_18);
    iText(280,440,"Computer Science And Engineering,",GLUT_BITMAP_HELVETICA_18);
    iText(280,420,"BUET",GLUT_BITMAP_HELVETICA_18);


    //printf("credits\n");

    iText(130,100,"1.Play",GLUT_BITMAP_HELVETICA_18);
    iText(230,100,"2.Highscore",GLUT_BITMAP_HELVETICA_18);
    iText(380,100,"4.Exit",GLUT_BITMAP_HELVETICA_18);
}


void gameOver(int score){
    int hScore[5]={},i;
    char str[10];

    drawTexture(0,0,bGround);

    itoa(score,str,10);
    iSetColor(67,3,168);
    iText(230,500,"Game Over",GLUT_BITMAP_HELVETICA_18);
    iText(230,400,"Your Score:",GLUT_BITMAP_HELVETICA_18);
    iText(350,400,str,GLUT_BITMAP_HELVETICA_18);

    FILE * fp;

    fp = fopen("flappy_highScore", "rb");
     if (fp == NULL) {
        printf("File doesn't exists!\n");
        fp = fopen("flappy_highScore", "wb");
    }

    while(fread(&hScore[i], sizeof(int), 1, fp) == 1) {
        i++;
    }
    fclose(fp);

    itoa(hScore[0],str,10);
    iText(230,350,"Highscore:",GLUT_BITMAP_HELVETICA_18);
    iText(350,350,str,GLUT_BITMAP_HELVETICA_18);

    if(score>hScore[0])
        iText(230,300,"New Highscore!!!",GLUT_BITMAP_HELVETICA_18);

    if(flag==0){

       if(score>hScore[0]){
            hScore[4]=hScore[3];
            hScore[3]=hScore[2];
            hScore[2]=hScore[1];
            hScore[1]=hScore[0];
            hScore[0]=score;
        }
        else if (score>hScore[1]){
            hScore[4]=hScore[3];
            hScore[3]=hScore[2];
            hScore[2]=hScore[1];
            hScore[1]=score;
        }
        else if (score>hScore[2]){
            hScore[4]=hScore[3];
            hScore[3]=hScore[2];
            hScore[2]=score;
        }
        else if (score>hScore[3]){
            hScore[4]=hScore[3];
            hScore[3]=score;
        }
        else if (score>hScore[4]){
            hScore[4]=score;
        }

         fp = fopen("flappy_highScore", "wb");
         for (i = 0; i < 5; i++) {
            fwrite(&hScore[i], sizeof(int), 1, fp);
        }
         fclose(fp);

         flag=1;
    }


    iText(130,200,"1.Play Again",GLUT_BITMAP_HELVETICA_18);
    iText(380,200,"2.Highscores",GLUT_BITMAP_HELVETICA_18);
    iText(130,100,"3.Credits",GLUT_BITMAP_HELVETICA_18);
    iText(380,100,"4.Exit",GLUT_BITMAP_HELVETICA_18);

}


void moveBall(double ball[]){
    ball[1]+=gravity;
    ball[0]+=ball[1];

}

int checkCollision(int x, double y, double blockX, double height, int score){

    if(y+radius>=600||y-radius<=0){
        PlaySound("sfx_hit&die.wav", NULL, SND_ASYNC);
        return 1;
    }
    else if( (x+radius>=blockX && x-radius<=blockX+width) && (y-radius<=height || y+radius>=height+gap ) ){
        PlaySound("sfx_hit&die.wav", NULL, SND_ASYNC);
        return 1;

    }
    else
        return 0;

}

void replayGame( double ballY[], double blocks[], double background[] ){
    ballY[0]=300;
    ballY[1]=0;
    blocks[0]=800;
    blocks[1]=width;
    blocks[3]=1200;
    blocks[4]=width;
    blocks[6]=1600;
    blocks[7]=width;
    blocks[9]=2000;
    blocks[10]=width;
    background[0]=0;
    background[1]=BG_Width;
    flag=0;
    flag2=0;

}


int currentScore(int score, int  ballX, double block ){
    if ((ballX-radius)>=block && flag2 == 0){

        score++;
        PlaySound("sfx_point.wav", NULL, SND_ASYNC);
        flag2=1;
        //printf("\a");
    }

    return score;
}
