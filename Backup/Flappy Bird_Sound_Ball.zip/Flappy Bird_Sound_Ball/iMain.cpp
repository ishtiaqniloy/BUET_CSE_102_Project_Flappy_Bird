# include "iGraphics.h"
# include "FlappyBird.h"
# include <windows.h>

#define ballX 180
#define radius 12
#define acc 6
#define width 60
#define BG_Width 1066



int x = 300, y = 300, r = 20;
int opt=0,col=1,score=0;
double blocks[12]={800,width,0,1200,width,0,1600,width,0,2000,width,0};
double background[2]={0,BG_Width};

double ballY[2]={300,0};           //y coordinate  of the ball and its velocity

/*
	function iDraw() is called again and again by the system.

	*/

void timedControl(){
    if(opt==1 && col==0){
        leftshift(blocks,background,score);
        moveBall(ballY);
        score=currentScore(score, ballX, blocks[0]+width);
    }

}

void playGame(){

    if(opt==1 && col==0){

        int i;
        char scr[5];
        itoa(score,scr,10);

        iClear();
        drawTexture(background[0],0,bGround);
        drawTexture(background[1],0,bGround);

        //drawTexture(300,300,pic);

        //score=currentScore(score, ballX, blocks[0]+width);
        buildblocks(blocks);

        //moveBall(ballY);
        iSetColor(0,0,255);
        iFilledCircle(ballX,ballY[0],radius,100);

        iText(20,560,"Score: ",GLUT_BITMAP_HELVETICA_18);
        iText(80,560,scr,GLUT_BITMAP_HELVETICA_18);
        col=checkCollision(ballX,ballY[0],blocks[0],blocks[2],score);

        if(col==1){
            /*for(i=0;i<2000;i++){
                drawTexture(background[0],0,bGround);
                drawTexture(background[1],0,bGround);

                //drawTexture(300,300,pic);

                //score=currentScore(score, ballX, blocks[0]+width);
                buildblocks(blocks);

                //moveBall(ballY);
                iSetColor(0,0,255);
                iFilledCircle(ballX,ballY[0],radius,100);

                iText(20,560,"Score: ",GLUT_BITMAP_HELVETICA_18);
                iText(80,560,scr,GLUT_BITMAP_HELVETICA_18);
            }*/

            opt=5;
        }



    }



}


void iDraw() {
    iClear();
    drawTexture(300,300,pic);
	opt=controlScreen(opt,score,col);
	playGame();


}

/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
	*/
void iMouseMove(int mx, int my) {
	printf("x = %d, y= %d\n",mx,my);
	//place your codes here
}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
	*/
void iMouse(int button, int state, int mx, int my) {
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        if(opt==1 && col==0){
            ballY[1] +=acc;
            //PlaySound("sfx_wing.wav", NULL, SND_ASYNC);

            if(ballY[1]>1.5*acc){
                ballY[1]=1.5*acc;
            }

        }



	}
/*	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
		//place your codes here
		x -= 10;
		y -= 10;
	}*/
}
void iMouseOver(int mx,int my){

    //px=mx;
    //qx=my;


    //printf("%d %d ",&mx,&my);

}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
	*/
void iKeyboard(unsigned char key) {
	if (key == '1' && col==1){
            score=0;
            replayGame(ballY, blocks, background);
            col=0;
            iClear();
            opt=1;
    }
    else if (key == '2' && col==1){
            iClear();
            opt=2;
    }
    else if (key == '3' && col==1){
            iClear();
            opt=3;
    }
    else if (key == '4' && col==1){
            iClear();
            opt=4;
    }
    else if (key == '5' && col==1){
            iClear();
            opt=5;
    }
    else if (key == ' ' && col==0){
        ballY[1] +=acc;
		if(ballY[1]>1.5*acc){
            ballY[1]=1.5*acc;
		}
    }
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
	*/
void iSpecialKeyboard(unsigned char key) {

	if (key == GLUT_KEY_END) {
		exit(0);
	}
	//place your codes for other keys here
}


int main() {
	//place your own initialization codes here.
	//PlaySound("sfx_point.wav", NULL, SND_ASYNC);
	int i;
	srand(time(NULL));
	for(i = 2; i < 12; i+=3){

         blocks[i] = rand()%500;
         printf("%d\n",blocks[i]);
	}

	iSetTimer(15,timedControl);
	iInitialize(600, 600, "Flappy Bird");
	return 0;
}
