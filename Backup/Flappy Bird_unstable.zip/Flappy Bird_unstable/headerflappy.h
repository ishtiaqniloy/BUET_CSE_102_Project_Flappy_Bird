#include<time.h>
#include<stdlib.h>

#define width 60
#define gap 90

void buildblocks(int x[]);
int leftshift(int x[]);


void buildblocks(int x[]){

    int i;
    iSetColor(255,0,0);
    leftshift(x);
    for(i = 0; i < 11; i+=3){
        iFilledRectangle(x[i], 0, x[i+1] , x[i+2]);
        iFilledRectangle(x[i], gap+x[i+2], x[i+1], 600-gap-x[i+2]);

    }
    if(x[1]==0){

        for(i = 0; i < 9; i++){
            x[i] = x[i+3];
        }
        x[9] = x[6]+300;
        x[11] = rand()%500;
        printf("%d\n",x[11]);
    }



}

int leftshift(int x[]){

        int i;
        for(i = 0; i < 12; i+=3){

        if(x[i] != 0){

            x[i]=x[i]-1;
        }
        else{

          x[i+1] = x[i+1]-1;

           }

        }
}
