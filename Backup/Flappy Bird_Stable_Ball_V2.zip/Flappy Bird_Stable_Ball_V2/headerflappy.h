#include<time.h>
#include<stdlib.h>

#define width 60
#define height 600
#define gap 90
#define speed 1
#define BG_Width 1066


void buildblocks(int x[]);
void leftshift(int x[], int y[], int score);


void buildblocks(int x[]){

    int i;
    iSetColor(255,0,0);
    //leftshift(x);
    for(i = 0; i < 11; i+=3){
        //iFilledRectangle(x[i], 0, x[i+1] , x[i+2]);
        //iFilledRectangle(x[i], gap+x[i+2], x[i+1], 600-gap-x[i+2]);

        drawTexture(x[i] , x[i+2]-height , pipe_Down);
        drawTexture(x[i] , x[i+2]+gap , pipe_Up);

    }

    if(x[0]==-60){

        for(i = 0; i < 9; i++){
            x[i] = x[i+3];
        }
        x[9] = x[6]+300;
        x[11] = rand()%500;
        printf("%d\n",x[11]);
    }



}

void leftshift(int x[] , int y[], int score){

        int i;



        for(i = 0; i < 12; i+=3){

            x[i]=x[i]-speed;

            /*if(x[i] > 0){

                x[i]=x[i]-speed;
            }

            else{

                x[i+1] = x[i+1]-speed;

            }*/

        }


            y[0]-=speed;
            y[1]-=speed;


        if(y[1]<=0){
            y[0]=0;
            y[1]=BG_Width;
        }


}


