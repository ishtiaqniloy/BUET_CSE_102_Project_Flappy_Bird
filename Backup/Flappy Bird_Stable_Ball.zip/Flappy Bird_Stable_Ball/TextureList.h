#include "texture.h"

//texture smurfTexture;
//texture character;
//texture background;

texture bGround;
texture pic;

void textureInit()
{
	//smurfTexture.Create("Nets_court_2.bmp");
	//character.Create("Flappy_Bird.bmp");
	bGround.Create("BG_1066.bmp");
    pic.Create("Bird.bmp");

}
